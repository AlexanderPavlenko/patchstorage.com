//
// Script for extracting parameters from *.fxb patch banks
//

// Run in the directory with *.fxb files

public class C {

    public static int MAX_PATCHES = 300 // maximum patches in a volume!

    public static int numVolume = 0
    public static String[] SSIG = []

    public static void process(String[] args) {
        List<File> files = [ ]

        for (String s : args) {
            File ff = new File(s)
            if ( ff.isDirectory() ) {
                for (File f : ff.listFiles()) {
                   String nm=f.getName()
                   if (!f.isDirectory() && (nm.endsWith('.fxb') || nm.endsWith('.FXB'))) {
                       files << f
                   }
                }
            } else {
                String nm=ff.getName()
                if (!ff.isDirectory() && (nm.endsWith('.fxb') || nm.endsWith('.FXB'))) {
                    files << ff
                }
            }
        }
        Map<String, File> map = [ : ]
        for (File f : files) map[ f.getName() ] = f
        String[] fnames = map.keySet().toArray(SSIG)
        Arrays.sort(fnames)

        
        int patchesSoFar = 0

        List<String> banksSoFar = [ ]
        List<String> namesSoFar = [ ]
        List<Integer> numPatchesPerBank = [ ]

        int fi=0
        for (String fname : fnames) {
            String name = fname
            fi++
            File f = map[ fname ]

            String bankName = name.substring(0, name.length()-'.fxb'.length())
            int pos=bankName.indexOf(' - ')
            if (pos > 0) {
                bankName=bankName.substring(pos + ' - '.length()).trim()
            }

            // Assemble patches in bank
            StringBuffer pb = new StringBuffer()
            int patchNo = 0 
            String content=f.text
            while ((pos = content.indexOf('<program programName="')) >=0) {
               content = content.substring(pos + '<program programName="'.length())
               pos=content.indexOf('"') 
               String patch='*UNKNOWN*'
               if (pos > 0) {
                   patch=unexpand(content.substring(0, pos))
                   content=content.substring(pos+1)
               }
               pos=content.indexOf('/>')
               if ( pos>0 ) {
                   if (patch=='Default' && seenDefault) {
                       // skip
                   } else if (patch=='--' && seenDashDash)  {
                       // skip
                   } else {
                       if (patch=='--') seenDashDash=true
                       if (patch=='Default') seenDefault=true
                       pb << "  elseif program = ${patchNo}\r\n"
                       makePatch( patchNo, pb, patch, content.substring(0, pos) )
                       patchNo++
                   }
                   content = content.substring( pos + 2 )
               }
            }

            // Emit the Result

            if ( fi < fnames.length 
                 && patchNo + patchesSoFar <= MAX_PATCHES ) {
                patchesSoFar = patchesSoFar + patchNo
                banksSoFar << pb.toString()
                namesSoFar << bankName
                numPatchesPerBank << patchNo
            } else {
                List<StringBuffer> newBanksSoFar = [ ]
                List<String> newNamesSoFar = [ ]
                List<Integer> newNumPatchesPerBank = [ ]
                int newPatchesSoFar = 0
                if ( fi < fnames.length && patchNo + patchesSoFar > MAX_PATCHES ) {
                    newBanksSoFar << pb.toString()
                    newNamesSoFar << bankName
                    newNumPatchesPerBank << patchNo
                    newPatchesSoFar = patchNo
                } else {
                    patchesSoFar = patchesSoFar + patchNo
                    banksSoFar << pb.toString()
                    namesSoFar << bankName
                    numPatchesPerBank << patchNo
                }
 
                StringBuffer bb = new StringBuffer()
                StringBuffer gs = new StringBuffer()
                gs << "\r\n"
                gs << "@go\r\n"
                gs << "  maxBank = ${banksSoFar.size() - 1}\r\n"
                gs << "  if bank < 0 or bank > maxBank\r\n"
                gs << "    bank = -1\r\n"

                for (int bi=0; bi<banksSoFar.size(); bi++) {
                    println "INFO: including bank ${namesSoFar.get(bi)} with ${numPatchesPerBank.get(bi)} patches!"
                    bb << "\r\n"
                    bb << "@Bank${bi}\r\n"
                    bb << "  if program < 0\r\n"
                    bb << "    LabelPads {Bank ${bi}: ${namesSoFar.get(bi)}}\r\n"
                    bb << "    patchesInBank = ${numPatchesPerBank.get(bi)}\r\n"
                    bb << "${banksSoFar.get(bi)}"
                    bb << "  endif\r\n"
                    bb << "@End\r\n"

                    gs << "  elseif bank = ${bi}\r\n"
                    gs << "    call @Bank${bi}\r\n"
                 }
                 gs << "  endif\r\n"
                 gs << "@End\r\n"


                 numVolume++
                 File outfile = new File( "obxd_v${numVolume}.txt" )            
                 outfile.withWriter{ def out -> out.write( gs.toString() ); out.write( bb.toString() ) }
                 println "INFO: wrote ${banksSoFar.size()} banks and ${patchesSoFar} patches to: ${outfile}"

                 banksSoFar = newBanksSoFar
                 namesSoFar = newNamesSoFar
                 numPatchesPerBank = newNumPatchesPerBank
                 patchesSoFar = newPatchesSoFar
            }
        }
    }
    private static String defaultPatch = null    
    private static StringBuffer gs = new StringBuffer()

    private static String unexpand(String s) {
        return replace(replace(replace(s, '&lt;', '<'), '&gt;', '>'), '&amp;', '&')
    }
    private static String replace(String s, String src, String tgt) {
        String res = ''
        int pos = 0
        while ( (pos = s.indexOf( src )) >= 0 ) {
            res = res + s.substring(0, pos) + tgt
            s = s.substring( pos + src.length() )
        }
        res = res + s
        return res
    }

    private static void makePatch(int pNo, StringBuffer sb, String patch, String params) {
        int pos = 0
        int count=0
        boolean openArray = false
        boolean first = true
        params=params.trim()

        List<Integer> paramList = [ ]
        
        sb.append( "    LabelPad pad, {${pNo}:${patch}}\r\n" )
        while ( (pos = params.indexOf('="')) > 0) {
            if (count % numPerArray == 0) {
                if (openArray) { sb.append(']\r\n'); openArray=false }
                sb.append( '    param[' + count + ']=[' )
                openArray = true
                first = true
            }
            params = params.substring(pos+2)
            pos=params.indexOf('"')
            if (first) {
                first=false
            } else {
                sb.append(',')
            }

            String val = params.substring(0, pos)
            // scale the value to 0..127
            Double d = Double.parseDouble( val )
            int res = Math.round( d * 127 )
            sb.append( '' + res )
            paramList << res
            count++
        }
        sb.append( ']\r\n' )
    }
    private static boolean seenDefault = false
    private static boolean seenDashDash = false
    private static int numPerArray = 25
    private static int counter=100;
}
if (args.length==0) {
    String[] ary = [ '.' ]
    C.process( ary )
} else {
    C.process( args )
}
